package testGUI;

public class Matriz {

	public int[][]  matriz () {
		
		int[][] estado = {{1,0,1},{1,0,1}};
		return estado;

	}

}

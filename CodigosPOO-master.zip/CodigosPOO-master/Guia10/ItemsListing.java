public class ItemsListing{

  public String item;

  public ItemsListing (String item ){
    this.item = item;
  }

  public String toString() {
    String s = "Item: " + item;
    return s;
  } 

}
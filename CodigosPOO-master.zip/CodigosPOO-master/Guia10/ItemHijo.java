public class ItemHijo extends ItemsListing{

  public ItemHijo (String item){
    super(item);
  }

  public String toString() {
    String s = "Item Hijo: " + item;
    return s;
  } 
}
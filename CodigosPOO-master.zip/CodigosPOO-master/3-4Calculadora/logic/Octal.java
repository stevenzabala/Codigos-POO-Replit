/*
 * Octal.java
 * 
 * Created on 4/04/2008, 01:38:26 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author alejo
 */
public class Octal extends Sistema{

    public Octal() {
        this.base=8;
    }

}

/*
 * Binario.java
 * 
 * Created on 4/04/2008, 01:37:43 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author alejo
 */
public class Binario extends Sistema{

    public Binario() {
        this.base=2;
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pryflecha;

/**
 *
 * @author alejo
 */
public class Flecha {
    String imagen;
    int coordenadaX;
    int coordenadaY;

    public int getCoordenadaX() {
        return coordenadaX;
    }

    public void setCoordenadaX(int coordenadaX) {
        this.coordenadaX = coordenadaX;
    }

    public int getCoordenadaY() {
        return coordenadaY;
    }

    public void setCoordenadaY(int coordenadaY) {
        this.coordenadaY = coordenadaY;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

}

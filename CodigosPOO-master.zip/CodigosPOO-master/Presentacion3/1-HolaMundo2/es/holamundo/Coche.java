package es.holamundo;

public class Coche extends Vehiculo {

}
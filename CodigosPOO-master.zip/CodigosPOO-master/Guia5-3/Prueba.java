public class Prueba {
  public static void main (String args[]){
    int i=5;
    while ( i > 0 ) {i --;}
    // las llaves aquí se podían haber omitido, puesto
    // que solo hay una sentencia.
    System.out.println("Ahora i vale "+ i); 
  }
}